#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>
#include <ext/hash_map>
#include <map>
#include <stack>
#include <queue>
#include <set>
#include "strutils.h"

using namespace std;
#define INFINITY 1<<20

namespace __gnu_cxx
{
	template<> struct hash< std::string >
	{
		size_t operator()( const std::string& x ) const
		{
			return hash< const char* >()( x.c_str() );
		}
	};
}

map<int,string> inverse_author_map;
__gnu_cxx::hash_map<string,int> author_map;

void read_graph_adjlist(string &filename, vector <vector <int> > &incoming_vertices, vector <vector <int> > &outgoing_vertices)
{
		ifstream fin(filename.c_str());
		string str;
		int unique_author_index = 0;
		bool first_line = true;
		while(getline(fin,str))
		{
				//cout<<str<<"\n";
				if(first_line)
				{
						istringstream iss(str);
						int num_vertices;
						iss>>num_vertices;
						incoming_vertices.resize(num_vertices);
						outgoing_vertices.resize(num_vertices);
						first_line = false;
						continue;
				}

				string node1,node2;
				int node1_index, node2_index;
				/*int index;
				if(directed)
				index = str.find("==>");

				else index = str.find("<==>");
				if(index == string::npos)
				{
						cerr << "The graph is not properly formatted "<<str<<"\n";
						exit(-1);
				}

				node1 = str.substr(0,index-1);
				node2 = str.substr(index+4, str.length()-index-4);
				*/
				vector <string> tokens;
				Tokenize_with_delimiter(str, &tokens, "\t");
				/*if(tokens.size() == 1)
				{
						node1 = tokens[0];
						Lowercase_string(node1);
						__gnu_cxx::hash_map<string,int>::iterator it = author_map.find(node1);
						if(it == author_map.end())
						{
								author_map[node1] = unique_author_index++;
								inverse_author_map[unique_author_index-1] = node1;
						}


						continue;
				}*/


				node1 = tokens[0];
				node2 = tokens[1];
				Lowercase_string(node1);
				Lowercase_string(node2);

				__gnu_cxx::hash_map<string,int>::iterator it = author_map.find(node1);

				if(it != author_map.end())
				{
						node1_index = it->second;
				}
				else
				{
						node1_index = unique_author_index++;
						author_map[node1] = node1_index;
						inverse_author_map[node1_index] = node1;
				}
				
				it = author_map.find(node2);
				
				if(it != author_map.end())
				{
						node2_index = it->second;
				}
				else
				{
						node2_index = unique_author_index++;
						author_map[node2] = node2_index;
						inverse_author_map[node2_index] = node2;
				}
				
				//cout<<node1_index<<": "<<inverse_author_map[node1_index]<<"\n";;
				//cout<<node2_index<<": "<<inverse_author_map[node2_index]<<"\n";

				//cout<<node1<<":\t"<<node1_index<<"\n"<<node2<<":\t"<<node2_index<<"\n";
				//adj_list[node1_index].push_back(node2_index);
				incoming_vertices[node2_index].push_back(node1_index);
				outgoing_vertices[node1_index].push_back(node2_index);
			
				/*if(!directed)
				{
					adj_list[node2_index].push_back(node1_index);
				}*/

		}
}

void compute_similarity_score(vector <vector <int> > &incoming_vertices, vector <vector <int> > &outgoing_vertices, int NUM_ITERATIONS, double C)
{
		vector <vector <double> > similarity_scores1;
		vector <vector <double> > similarity_scores2;

		double alpha = 0.5;
		int num_vertices = incoming_vertices.size();
		//num_vertices = 10;
		similarity_scores1.resize(num_vertices);
		similarity_scores2.resize(num_vertices);
		for(int i=0;i<num_vertices;i++)
		{
				
				similarity_scores1[i].resize(num_vertices);
				similarity_scores2[i].resize(num_vertices);
				for(int j=0;j<num_vertices;j++)
				{
						similarity_scores1[i][j] = 0;
						similarity_scores2[i][j] = 0;
				}
				//cout<<"initialized values\n";
				similarity_scores1[i][i] = 1;
				similarity_scores2[i][i] = 1;
				cout<<i<<" vertices initialized\n";
		}

		//cout<<"done initializing\n";		

		for(int num_iterations = 0;num_iterations < NUM_ITERATIONS;num_iterations++)
		{
			for(int i=0;i<num_vertices;i++)
			{
					for(int j=0;j<num_vertices;j++)
					{
							if(i == j) continue;
							double temp_sum1 = 0;
							double temp_sum2 = 0;
							double incoming_sim_component = 0;
							double outgoing_sim_component = 0;
							for(int k=0;k<incoming_vertices[i].size();k++)
							{
									for(int l = 0;l < incoming_vertices[j].size();l++)
									{
											if(num_iterations%2 == 0)
											{
													temp_sum1 += similarity_scores1[k][l];
											}
											else
											{

													temp_sum1 += similarity_scores2[k][l];
											}

									}
							}

							for(int k=0;k<outgoing_vertices[i].size();k++)
							{
									for(int l=0;l<outgoing_vertices[j].size();l++)
									{
											
											if(num_iterations%2 == 0)
											{
													temp_sum2 += similarity_scores1[k][l];
											}
											else
											{

													temp_sum2 += similarity_scores2[k][l];
											}

									}
							}
							if(incoming_vertices[i].size() == 0 || incoming_vertices[j].size() == 0)
							{
									incoming_sim_component  = 0;
									//similarity_scores1[i][j] = 0;
									//similarity_scores2[i][j] = 0;
							}

							else
							{
									incoming_sim_component = (C/(incoming_vertices[i].size()*incoming_vertices[j].size()))*temp_sum1;

							}

							if(outgoing_vertices[i].size() == 0 || outgoing_vertices[j].size() == 0)
							{
									outgoing_sim_component = 0;
							}

							else
							{
									outgoing_sim_component = (C/(outgoing_vertices[i].size()*outgoing_vertices[j].size()))*temp_sum2;

							}

							if(num_iterations%2 == 0)
							{
									similarity_scores2[i][j] = alpha*incoming_sim_component + (1-alpha)*outgoing_sim_component;
							}
							else
							{
									similarity_scores1[i][j] = alpha*incoming_sim_component + (1-alpha)*outgoing_sim_component;
							}					

							//cout<<"one pair completed\n";
					}
					//cout<<i+1<<" vertices processed\n";
			}
			cout<<num_iterations<<" iterations completed\n";
		}

		for(int i=0;i<num_vertices;i++)
		{
				for(int j=i+1;j<num_vertices;j++)
				{
						if(NUM_ITERATIONS%2 == 0)
						{

								cout<<inverse_author_map[i]<<"\t"<<inverse_author_map[j]<<"\t"<<similarity_scores1[i][j]<<"\n";
						}
						else
						{
								cout<<inverse_author_map[i]<<"\t"<<inverse_author_map[j]<<"\t"<<similarity_scores2[i][j]<<"\n";
						}
				}
		}
}



int main(int argc, char *argv[])
{

		if(argc < 3)
		{
				cout << "USAGE: ./a.out file_name num_iterations\n";
				cout<<" file_name contains the graph in edgelist format\n";
				cout<<" num_iterations is the number of iterations to run the SimRank algorithm for\n";
				exit(-1);
		}

		string filename(argv[1]);
		int num_iterations = atoi(argv[2]);

		vector <vector <int> > incoming_vertices, outgoing_vertices;
		read_graph_adjlist(filename, incoming_vertices, outgoing_vertices);
		cout<<"read graph\n";
		compute_similarity_score(incoming_vertices,outgoing_vertices, num_iterations, 0.8);
		return 0;
}
