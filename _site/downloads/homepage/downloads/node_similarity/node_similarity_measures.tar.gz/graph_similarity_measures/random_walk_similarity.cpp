//An Efficient implementation of Harel and Koren's similarity measure for sparse graphs

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <queue>
#include <map>

#include "strutils.h"

using namespace std;

map<string,int> vertex_labels;
map<int,string> inverse_vertex_labels;


void read_graph_adjlist(string filename, vector<vector<pair<int,double> > > &adj_list)
{
		ifstream fin(filename.c_str());
		int num_vertices;
		int unique_vertex_id = 0;
		string str;

		getline(fin,str);
		istringstream iss(str);
		iss>>num_vertices;

		adj_list.resize(num_vertices);

		while(getline(fin,str))
		{
				vector <string> tokens;
				Tokenize_with_delimiter(str,&tokens,"\t");
				if(tokens.size() != 3)
				{
						cout<<"Input graph not well formatted\n";
						exit(-1);
				}
				int id1,id2;
				map<string,int> :: iterator it = vertex_labels.find(tokens[0]);
				if(it == vertex_labels.end())
				{
						vertex_labels[tokens[0]] = unique_vertex_id;
						inverse_vertex_labels[unique_vertex_id] = tokens[0];
						id1 = unique_vertex_id++;
				}
				else id1 = it->second;

				it = vertex_labels.find(tokens[1]);
				if(it == vertex_labels.end())
				{
						vertex_labels[tokens[1]] = unique_vertex_id;
						inverse_vertex_labels[unique_vertex_id] = tokens[1];
						id2 = unique_vertex_id++;
				}

				else id2 = it->second;

				double weight;
				istringstream iss(tokens[2]);
				iss >> weight;

				adj_list[id1].push_back(make_pair(id2,weight));
				adj_list[id2].push_back(make_pair(id1,weight));
		}
}

void normalize_graph(vector <vector <pair<int,double> > > &adj_list)
{
		double normalizing_weight = 0;
		for(int i=0;i<adj_list.size();i++)
		{
				for(int j=0;j<adj_list[i].size();j++)
				{
						normalizing_weight += adj_list[i][j].second;
				}
				for(int j=0;j<adj_list[i].size();j++)
				{
						adj_list[i][j].second /= normalizing_weight;
				}
		}
}

void print_graph(vector <vector <pair<int,double> > > &adj_list)
{
		for(int i=0;i<adj_list.size();i++)
		{
				cout<<i<<"'s neighbors\n";
				for(int j=0;j<adj_list[i].size();j++)
				{
						cout<<adj_list[i][j].first<<" "<<adj_list[i][j].second<<"\n";
				}
		}
}


double vector_similarity(vector <double> &a, vector <double> &b, int k)
{
		double l1_norm = 0;
		for(int i=0;i<a.size();i++)
		{
				l1_norm += abs(a[i] - b[i]);
		}

		return (exp(2*k - l1_norm) -1)/(exp(2*k) - 1);
}

vector <double> compute_random_walk(vector <vector <pair<int,double> > > &adj_list, int v, int k)
{
		int start = v;
		queue <pair<pair<int,double>,int> > q;
		vector <double> random_walk_prob;
		random_walk_prob.resize(adj_list.size());
		for(int i=0;i<adj_list.size();i++)
		{
				random_walk_prob[i] = 0;
		}
		q.push(make_pair(make_pair(start,1),0));
		while(!q.empty())
		{
				pair<pair<int,double>,int> a = q.front();
				q.pop();
				random_walk_prob[(a.first).first] += (a.first).second;

				if(a.second == k)
						continue;
				for(int i=0;i<adj_list[a.first.first].size();i++)
				{
						pair<pair<int,double>,int> b;
						b.first = make_pair(adj_list[a.first.first][i].first,adj_list[a.first.first][i].second*(a.first).second);
						b.second = a.second+1;
						q.push(b);
				}
		}
		return random_walk_prob;
}



vector <pair<pair<int,int>, double > >  compute_similarity(string filename, int k, string output_file)
{
		vector <vector <pair<int,double> > > adj_list;
		ofstream fout(output_file.c_str());

		read_graph_adjlist(filename,adj_list);
		normalize_graph(adj_list);

		//print_graph(adj_list);

		vector <vector <double> > random_walk_prob;
		random_walk_prob.resize(adj_list.size());

		for(int i=0;i<adj_list.size();i++)
		{
			random_walk_prob[i] = compute_random_walk(adj_list,i,k);
//			cout<<"Computed "<<i<<" random walks\n";
		}
//		cout<<"done computing random walks\n";
		vector <pair<pair<int,int>, double> > result;
		for(int i=0;i<adj_list.size();i++)
		{
				for(int j=i+1;j<adj_list.size();j++)
				{
						double similarity = vector_similarity(random_walk_prob[i],random_walk_prob[j], k);
						result.push_back(make_pair(make_pair(i,j),similarity));
						fout<<inverse_vertex_labels[i]<<"\t"<<inverse_vertex_labels[j]<<"\t"<<similarity<<"\n";
				}
		}
		return result;
}


int main(int argc, char *argv[])
{
		string filename(argv[1]);
		string output_file(argv[2]);
		int k = 5;
		if(argc == 4)
		{
			k = atoi(argv[3]);
		}
		compute_similarity(filename,k,output_file);
		return 0;
}
