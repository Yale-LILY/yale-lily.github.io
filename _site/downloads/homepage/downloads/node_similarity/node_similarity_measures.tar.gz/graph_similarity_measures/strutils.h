#include <string>
#include <vector>

using namespace std;

void Tokenize(const string &str, vector <string> &tokens);

void Lowercase_string(string &str);

void Trim(string &str,const string &delimiters);

int Tokenize_with_delimiter(const string &str,vector <string> * sentences, const string delimiters = ".,;!\t\"\n ():?'");

void strip(string &);
string itoa(int x);

bool consists_alphanum(string &x);

int num_common_tokens(vector <string> &tokens1, vector <string> &tokens2);

