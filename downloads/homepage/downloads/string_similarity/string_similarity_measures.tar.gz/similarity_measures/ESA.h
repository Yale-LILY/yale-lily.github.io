#ifndef ESA_H
#define ESA_H

#include "DataType.h"
#include "ErrorCode.h"
#include "LCP.h"
#include "ChildTable.h"
#include "I_LCPFactory.h"
#include "I_SAFactory.h"
#include <vector>
#include <algorithm>


//#define SLINK


class ESA
{
  
 private:
 
  int _verb;
  
 public:

  UInt32      size;            //' The length of #text#
	SYMBOL      *text;           //' Text corresponds to SA
  UInt32      *suftab;         //' Suffix Array
	LCP         lcptab;          //' LCP array
	ChildTable  childtab;        //' Child table (fields merged)
	UInt32      *suflink;        //' Suffix link table. Two fields: l,r
	

	//' --- for bucket table ---
	UInt32      bcktab_depth;    //' Number of char defining each bucket
	UInt32      bcktab_size;     //' size of bucket table
	UInt32      *bcktab_val;     //' value column of bucket table

	UInt32      *bcktab_key4;    //' 4-bytes key column of Bucket table
	UInt32      *coef4;
	UInt32      hash_value4;

	UInt64      *bcktab_key8;    //' 8-bytes key column of Bucket table
	UInt64      *coef8;
	UInt64      hash_value8;
	//' ---
  

	/// Constructors
	ESA(const UInt32 & size_, SYMBOL *text_, int verb=INFO);

	/// Destructor
	virtual ~ESA();

	/// Construct child table
	ErrorCode ConstructChildTable();


	/// Get suffix link interval
	ErrorCode GetSuflink(const UInt32 &i, const UInt32 &j,
											 UInt32 &sl_i, UInt32 &sl_j);


	/// Find the suffix link
	ErrorCode FindSuflink(const UInt32 &parent_i, const UInt32 &parent_j,
												const UInt32 &child_i, const UInt32 &child_j,
												UInt32 &sl_i, UInt32 &sl_j);
												
	/// Construct suffix link table
	ErrorCode ConstructSuflink();

	/// Construct bucket table
	ErrorCode ConstructBcktab(const UInt32 &alphabet_size=256);

	
	/// Get all non-singleton child-intervals
	ErrorCode GetChildIntervals(const UInt32 &lb, const UInt32 &rb, 
															std::vector<std::pair<UInt32,UInt32> > &q);

	/// Get intervals by index
	ErrorCode GetIntervalByIndex(const UInt32 &parent_i, const UInt32 &parent_j,
															 const UInt32 &start_idx, UInt32 &child_i, 
															 UInt32 &child_j);

	/// Get intervals by character
	ErrorCode GetIntervalByChar(const UInt32 &parent_i, const UInt32 &parent_j,
															const SYMBOL &start_ch, const UInt32 &depth,
															UInt32 &child_i, UInt32 &child_j);
	/// Get lcp value
	ErrorCode GetLcp(const UInt32 &i, const UInt32 &j, UInt32 &val);

	/// Compare pattern to text[suftab[idx]..length].
	ErrorCode Compare(const UInt32 &idx, const UInt32 &depth, SYMBOL *pattern, 
										const UInt32 &p_len, UInt32 &matched_len);

	/// Find longest substring of pattern in enhanced suffix array.
	ErrorCode Match(const UInt32 &i, const UInt32 &j, SYMBOL *pattern, const UInt32 p_len,
									UInt32 &lb, UInt32 &rb,	UInt32 &matched_len);

	/// Similar to Match() but returns also floor interval of [lb..rb]
	ErrorCode ExactSuffixMatch(const UInt32 &i, const UInt32 &j, const UInt32 &offset,
														 SYMBOL *pattern, const UInt32 p_len, UInt32 &lb, UInt32 &rb,	
														 UInt32 &matched_len, UInt32 &floor_lb, UInt32 &floor_rb,
														 UInt32 &floor_len);
	
};
#endif
