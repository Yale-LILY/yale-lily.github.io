#ifndef I_LCPFACTORY_H
#define I_LCPFACTORY_H

#include "DataType.h"
#include "ErrorCode.h"
#include "LCP.h"

class I_LCPFactory
{

	public:

		/// Constructor
		I_LCPFactory(){}

		/// Destructor
		virtual ~I_LCPFactory(){}

		/// Methods
		virtual ErrorCode ComputeLCP(const SYMBOL *text, const UInt32 &length, 
				const UInt32 *sa,  LCP& lcp)=0;

};
#endif
