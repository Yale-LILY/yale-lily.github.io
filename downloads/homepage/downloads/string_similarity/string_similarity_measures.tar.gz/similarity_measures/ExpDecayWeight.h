#ifndef EXPDECAYWEIGHT_H
#define EXPDECAYWEIGHT_H

#include "DataType.h"
#include "ErrorCode.h"
#include "I_WeightFactory.h"
#include <iostream>

class ExpDecayWeight : public I_WeightFactory
{

public:

	Real lambda;

	/// Constructors

  //' NOTE: lambda shouldn't be equal to 1, othexrwise there will be 
  //'         divide-by-zero error.
	ExpDecayWeight(const Real &lambda_=2.0):lambda(lambda_) {}


	/// Destructor
	virtual ~ExpDecayWeight(){}


	/// Compute weight
	ErrorCode ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len, Real &weight);

};
#endif
