#include <iostream>

#include <fstream>
#include <vector>
#include <string>

using namespace std;


struct StringPair
{
		double quality;
		string s1;
		string s2;
		string id1,id2;
};

class Similarity
{
		string metric;
		double threshold;
		vector <StringPair> data;
		int p;
		vector <double> scores;

		bool binary_scoring;
		public:
				Similarity(){p = 7;}
				Similarity(string dataset_file, string conf_file);
				double CosineSimilarity(char *st1, char *st2);
				double LengthWeightedKernel(string &s1, string &s2);
				void CosineSimilarityEval();
				double JaccardSimilarity( string &s1, string &s2);
				void JaccardSimilarityEval();
				double PSpectrumKernel( string s1,  string s2);
				void PSpectrumKernelEval();
				void RandomEval();
				void LengthWeightedKernelEval();
				double Eval();
};



