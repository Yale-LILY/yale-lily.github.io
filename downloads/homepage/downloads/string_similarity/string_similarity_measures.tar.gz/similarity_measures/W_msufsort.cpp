//' Wrapper for Michael Maniscalco's MSufSort version 2.2 algorithm
#ifndef W_MSUFSORT_CPP
#define W_MSUFSORT_CPP

#include "W_msufsort.h"
#include <iostream>
#include <cstring>
#include <cassert>


W_msufsort::W_msufsort()
{
	msuffixsorter = new MSufSort();
}

W_msufsort::~W_msufsort()
{
	delete msuffixsorter;
}


/**
 *  Construct Suffix Array using Michael Maniscalco's algorithm
 *
 *  \param _text - (IN) The text which resultant SA corresponds to.
 *  \param _len  - (IN) The length of the text.
 *  \param _sa   - (OUT) Suffix array instance.
 */
ErrorCode
W_msufsort::ConstructSA(SYMBOL *text, const UInt32 &len, UInt32 *&array){

	//' A temporary copy of text
	SYMBOL *text_copy = new SYMBOL[len];

	//' chteo: BUGBUG
	//' redundant?
	assert(text_copy != NULL);

	memcpy(text_copy, text, sizeof(SYMBOL)*len);
	msuffixsorter->Sort(text_copy, len);
	
	//' Code adapted from MSufSort::verifySort()	
	for (UInt32 i = 0; i < len; i++) {
		UInt32 tmp = msuffixsorter->ISA(i)-1;
		array[tmp] = i;
	}

	//' Deallocate the memory allocated for #text_copy#
	delete [] text_copy;
	
	return NOERROR;
}
#endif



