#include "strutils.h"
#include <algorithm>
using namespace std;


//Tokenizes the string, str, and puts the tokens into the vector, anything apart from alphabets (a-zA-z) and apostrophe, everything is a delimiter

bool consists_alphanum(string &x)
{
		for(int i=0;i<x.length();i++)
		{
				if(isalnum(x[i]))return true;
		}
		return false;
}


void Tokenize(const string &str, vector <string> &tokens)
{
	string token;
	for(int i=0; i<str.length(); ++i)
	{	
		if(isalpha(str[i]) || str[i] == '\'')
		{
			token += str[i];
		}
		
		else
		{
			if(token != "")
			{
				tokens.push_back(token);
				token = "";
			}
		}
	}
	if(token != "")
		tokens.push_back(token);
}


//Lowercases the string, str
void Lowercase_string(string &str)
{
	for(int i=0;i < str.length();  i++)
	{
		str[i] = tolower(str[i]);
	}
}

//Trims the string str, removing all the leading and trailing delimiters.
void Trim(string &str,const string &delimiters)
{
	int index1 = str.find_first_not_of(delimiters);
	int index2 = str.find_last_not_of(delimiters);
	if(index1 >= 0 && index1 < str.length() && index2 >= 0 && index2 < str.length())
	str = str.substr(index1, index2 - index1 +1);
}


//Tokenizes the string given the delimiters
int Tokenize_with_delimiter(const string &str,vector <string> * sentences, const string delimiters)
{
  int num_words = 0;
  string::size_type lastPos = str.find_first_not_of(delimiters);
  string::size_type pos  = str.find_first_of(delimiters, lastPos);
  while (string::npos != pos || string::npos != lastPos)
  {
    sentences->push_back(str.substr(lastPos,pos-lastPos));
    lastPos = str.find_first_not_of(delimiters, pos);
    pos = str.find_first_of(delimiters, lastPos);
    num_words++;

  }
  return sentences->size();;
}


string itoa(int t)
{
	if(t == 0) return "0";
	string ans = "";
	while(t)
	{
		int rem = t%10;
		ans += (rem+'0');
		t/=10;
	}
	reverse(ans.begin(),ans.end());
	return ans;
}

int num_common_tokens(vector <string> &tokens1, vector <string> &tokens2)
{
		sort(tokens1.begin(), tokens1.end());
		sort(tokens2.begin(), tokens2.end());
		int matches = 0;
		for(int i = 0, j = 0; i < tokens1.size() && j < tokens2.size();)
		{
				if(tokens1[i] == tokens2[j])
				{
						matches++;
						i++;
						j++;
				}
				else if(tokens1[i] < tokens2[j])
				{
						i++;
				}
				else j++;
		}
		return matches;
}


