//' Wrapper for Michael Maniscalco's MSufSort version 2.2 algorithm
#ifndef W_MSUFSORT_H
#define W_MSUFSORT_H

#include "DataType.h"
#include "I_SAFactory.h"
#include "MSufSort.h"


class W_msufsort : public I_SAFactory
{

 public:

	///Variables

	//'Declaration of object POINTERS, no initialization needed.
	//'If Declaration of objects, initialize them in member initialization list.
	MSufSort *msuffixsorter;
	
	///Constructor
	W_msufsort();

	///Destructor
	virtual ~W_msufsort();

	///Methods
	ErrorCode ConstructSA(SYMBOL *text, const UInt32 &len, UInt32 *&array);

};
#endif
