//' Interface for Enhanced Suffix Array construction algorithms
#ifndef I_SAFACTORY_H
#define I_SAFACTORY_H

#include "DataType.h"
#include "ErrorCode.h"


class I_SAFactory
{

	public:

		///Constructor
		I_SAFactory(){}

		///Destructor
		virtual ~I_SAFactory(){}

		///Methods
		virtual ErrorCode ConstructSA(SYMBOL *text, const UInt32 &len, UInt32 *&array)=0;

};
#endif
