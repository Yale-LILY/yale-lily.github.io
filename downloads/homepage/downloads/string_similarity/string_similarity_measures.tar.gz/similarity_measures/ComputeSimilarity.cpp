#include <iostream>
#include <fstream>
#include <string>
#include <vector>


#include "Similarity.h"
#include "strutils.h"

using namespace std;

void print_error(string &line, int line_num)
{
		cerr << "Error in input file on line number "<<line_num<<"\n";
		cerr<<line<<"\n";
}

double compute_similarity(string text1, string text2, string similarity_metric)
{
		Similarity s;

		double sim_score;
		if(similarity_metric == "pspectrum")
		{
				sim_score	= s.PSpectrumKernel(text1,text2);
		}
		else if (similarity_metric == "jaccard")
		{
				sim_score	= s.JaccardSimilarity(text1,text2);

		}
		else if(similarity_metric == "lengthweighted")
		{
				sim_score	= s.LengthWeightedKernel(text1,text2);

		}
		else if (similarity_metric == "cosine")
		{
				sim_score	= s.CosineSimilarity((char *)text1.c_str(),(char *)text2.c_str());

		}
		else
		{
				cerr <<"Similarity metric should be one of the following four options\n";
				cerr <<"1. P-Spectrum Kernel (pspectrum)\n";
				cerr <<"2. Length Weighted Kernel (lengthweighted)\n";
				cerr <<"3. Cosine Similarity (cosine)\n";
				cerr <<"4. Jaccard Similarity (jaccard)\n";
				exit(-1);
		}
		return sim_score;
}

string extract_text(string &line, string &start_tag, string &end_tag)
{
		int start_index = line.find(start_tag);
		int start_len = start_tag.length();
		int end_index = line.find(end_tag);
		string text = line.substr(start_index + start_len, end_index - start_index - start_len);
		Trim(text," \t\n");
		return text;
}

void read_xml(char *fname, string kernel, double threshold, string outfile)
{
		ifstream fin(fname);
		string str;

		int line_num = 1;
		int state = 1;
		string text1,text2,cluster_id,source;
		string sid1,sid2;
		double similarity_score;
		bool similar;
		int tp = 0, tn = 0;
		int fp = 0, fn = 0;

		bool similar_defined = 0;
		bool output_flag = 0;
		ofstream fout;
		if(outfile != "")
		{
			fout.open(outfile.c_str());
			output_flag = 1;
		}

		while(getline(fin,str))
		{
				line_num++;
				//cout<<str<<"\n";
				if(!consists_alphanum(str)) continue;
				Lowercase_string(str);
				switch(state)
				{
						case 1: if(str.find("<cluster>")  != string::npos)
								{
										state = 2;
								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;

						case 2: if(str.find("<cluster_id>")  != string::npos)
								{
										string start_tag = "<cluster_id>";
										string end_tag = "</cluster_id>";
										cluster_id = extract_text(str,start_tag,end_tag);
										state = 3;
								}
								else
								{
										print_error(str,line_num);	
										exit(-1);
								}
								break;
						case 3: if(str.find("<source>") != string::npos)
								{
										string start_tag = "<source>";
										string end_tag = "</source>";
										source = extract_text(str,start_tag,end_tag);
										state = 4;
								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;

						case 4: if(str.find("<sentence_pair") != string::npos)
								{
										state = 5;
								}
								else if(str.find("</cluster>") != string::npos)
								{
										//cout<<"done reading all sentence pairs\n";

								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;

						case 5: if(str.find("<sid1>") != string::npos)
								{
										string start_tag = "<sid1>";
										string end_tag = "</sid1>";
										sid1 = extract_text(str,start_tag, end_tag);
										state = 6;

								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;

						case 6: if(str.find("<text1>") != string::npos)
								{
										string start_tag = "<text1>";
										string end_tag = "</text1>";
										text1 = extract_text(str, start_tag, end_tag);
										state = 7;
								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;

						case 7: if(str.find("<sid2>") != string::npos)
								{
										string start_tag = "<sid2>";
										string end_tag = "</sid2>";
										sid2 = extract_text(str, start_tag, end_tag);
										state = 8;
								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;

						case 8: if(str.find("<text2>") != string::npos)
								{
										string start_tag = "<text2>";
										string end_tag = "</text2>";
										text2 = extract_text(str, start_tag, end_tag);
										state = 9;
								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;

						case 9: if(str.find("<similar>") != string::npos)
								{
										similar_defined = 1;
										string start_tag = "<similar>";
										string end_tag = "</similar>";
										string sim = extract_text(str, start_tag, end_tag);

										if(sim == "y" )
										{
												similar = 1;
										}
										else 
										{
												similar = 0;
										}
										state = 9;
								}
								else if(str.find("</sentence_pair>") != string::npos)
								{
										//cout<<"text1 is \""<<text1<<"\"\ntext2 is \""<<text2<<"\"\n\n";
										double similarity_score = compute_similarity(text1, text2, kernel);
										//cout<<"similarity score = "<<similarity_score<<"\n";

										/*if(similar_defined)
										{
											cout<<"Ground Truth: \n";
											if(similar)
													cout<<"They are similar\n";
											else 
													cout<<"They are not similar\n";
										}*/


										if(similar_defined)
										{
												if(similarity_score > threshold && similar == 1)
												{
														tp++;
												}
												if(similarity_score <= threshold && similar == 0)
												{
														tn++;
												}
												if(similarity_score > threshold && similar == 0)
												{
														fp++;
												}
												if(similarity_score <= threshold && similar == 1)
												{
														fn++;
												}
										}
										if(output_flag)
										{
												fout<<sid1<<"\t"<<sid2<<"\t"<<similarity_score<<"\n";
										}

										text1 = "";
										text2 = "";
										state = 4;

								}
								else
								{
										print_error(str,line_num);
										exit(-1);
								}
								break;
				}
		}
		fout.close();
		if(similar_defined)
		{
				double precision = (double)tp/(tp + fp);
				double recall = (double)tp/(tp + fn);
				cout<<"Precision = "<<tp<<"/"<<(tp+fp)<<" = "<<precision<<"\n";
				cout<<"Recall = "<<tp<<"/"<<(tp+fn)<<" = "<<recall<<"\n";
		}
}


int main(int argc, char *argv[])
{

		if(argc <  4)
		{
				cerr << " ./ComputeSimilarity path/to/input_xml_file similarity_metric threshold\n";
				cerr << " \n\nExample:\n./ComputeSimilarity msr_paraphrase.xml pspectrum 0.6\n";
				exit(-1);
		}
		string kernel(argv[2]);
		double threshold = strtod(argv[3],NULL);
		if(argc == 5)
		{
			string outfile(argv[4]);
			read_xml(argv[1],kernel, threshold, outfile);
		}
		else
		{
			read_xml(argv[1],kernel, threshold, "");
		}


		return 0;
}	

