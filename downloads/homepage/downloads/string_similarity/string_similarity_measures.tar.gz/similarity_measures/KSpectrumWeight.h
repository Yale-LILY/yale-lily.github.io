#ifndef KSPECTRUMWEIGHT_H
#define KSPECTRUMWEIGHT_H

#include "DataType.h"
#include "ErrorCode.h"
#include "I_WeightFactory.h"
#include <iostream>

//' K-spectrum weight class
class KSpectrumWeight : public I_WeightFactory
{

  Real k;
public:

	/// Constructor
	KSpectrumWeight(const Real &k_=5):k(k_) {}

	/// Destructor
	virtual ~KSpectrumWeight(){}

	/// Compute weight
	ErrorCode ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len, Real &weight);
};
#endif
