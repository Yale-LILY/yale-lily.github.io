#ifndef I_WEIGHTFACTORY_H
#define I_WEIGHTFACTORY_H

#include "DataType.h"
#include "ErrorCode.h"


/// Weight Factory interface for string kernel
class I_WeightFactory
{

 public:
	/// Constructor
	I_WeightFactory(){}
	
	/// Destructor
	virtual ~I_WeightFactory(){}

	/// Compute edge weight between floor interval and the end of matched substring.
	virtual ErrorCode ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len,
																	Real &weight)=0;
};
#endif
