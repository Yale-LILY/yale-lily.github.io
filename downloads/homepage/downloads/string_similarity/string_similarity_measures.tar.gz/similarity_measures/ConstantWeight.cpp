#ifndef CONSTANTWEIGHT_CPP
#define CONSTANTWEIGHT_CPP

#include "ConstantWeight.h"
#include <cassert>

/**
 *  Constant weight function. Computes number of common substrings. Every 
 *    matched substring is of same weight (i.e. 1)
 *  W(y,t) := tau - gamma
 *
 *  \param floor_len - (IN) Length of floor interval of matched substring.
 *                            (cf. gamma in VisSmo02).
 *  \param x_len     - (IN) Length of the matched substring.
 *                            (cf. tau in visSmo02).
 *  \param weight    - (OUT) The weight value.
 *
 */
ErrorCode
ConstantWeight::ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len,	Real &weight)
{
	//' Input validation
	assert(x_len >= floor_len);
		
	//' x_len == floor_len when the substring found ends on an interval.

	weight = (x_len - floor_len);

//   std::cout << "floor_len : " << floor_len
//             << "   x_len : " << x_len
//             << "   weight : " << weight << std::endl;

	return NOERROR;
}

#endif
