
#ifndef CHILDTABLE_H
#define CHILDTABLE_H

#include "DataType.h"
#include "ErrorCode.h"
#include "LCP.h"
#include <vector>
#include <iostream>

// using namespace std;

/**
 *  ChildTable represents the parent-child relationship between
 *  the lcp-intervals of suffix array.
 *  Reference: AboKurOhl04
 */
class ChildTable : public std::vector<UInt32>
{
	
 private:
  // childtab needs lcptab to differentiate between up, down, and
	//  nextlIndex values.
	LCP& _lcptab;
  
 public:
	
	// Constructors
	ChildTable(const UInt32 &size, LCP& lcptab): std::vector<UInt32>(size), 
    _lcptab(lcptab){ }
  
	// Destructor
	virtual ~ChildTable() { }

  
	// Get first l-index of an l-[i..j] interval
	ErrorCode l_idx(const UInt32 &i, const UInt32 &j, UInt32 &idx);
  
	// .up field
	ErrorCode up(const UInt32 &idx, UInt32 &val);

	// .down field
	ErrorCode down(const UInt32 &idx, UInt32 &val);

	// .next field can be retrieved by accessing the array directly.

  friend std::ostream& operator << (std::ostream& os, 
                                    const ChildTable& ct); 

};
#endif
