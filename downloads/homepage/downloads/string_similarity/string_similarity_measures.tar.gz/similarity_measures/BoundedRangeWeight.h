#ifndef BOUNDEDRANGEWEIGHT_H
#define BOUNDEDRANGEWEIGHT_H

#include "DataType.h"
#include "ErrorCode.h"
#include "I_WeightFactory.h"
#include <iostream>

//' Bounded Range weight class
class BoundedRangeWeight : public I_WeightFactory
{

	Real n;
public:

	/// Constructor
	BoundedRangeWeight(const Real &n_=1): n(n_){}

	/// Destructor
	virtual ~BoundedRangeWeight(){}

	/// Compute weight
	ErrorCode ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len, Real &weight);
};
#endif
