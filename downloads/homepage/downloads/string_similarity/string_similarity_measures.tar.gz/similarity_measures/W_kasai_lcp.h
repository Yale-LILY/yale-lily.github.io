#ifndef W_KASAI_LCP_H
#define W_KASAI_LCP_H

#include "DataType.h"
#include "ErrorCode.h"
#include "I_LCPFactory.h"
#include "LCP.h"

/**
 * Kasai et al's LCP array computation algorithm is
 * is slightly faster than Manzini's algorithm. However,
 * it needs inverse suffix array which costs extra memory.
 */
class W_kasai_lcp : public I_LCPFactory
{

	public:

		/// Constructor
		W_kasai_lcp(){}

		/// Desctructor
		virtual ~W_kasai_lcp(){}

		/// Compute LCP array.
		ErrorCode	ComputeLCP(const SYMBOL *text, const UInt32 &len, 
				const UInt32 *sa, LCP& lcp);

};
#endif
