#include <sstream>
#include <sys/time.h>
#include <cmath>

#include "DataType.h"
#include "ErrorCode.h"
#include "ESA.h"

#include "StringKernel.h"
#include "Similarity.h"
#include "strutils.h"


using namespace std;



#define MAX_WORDS 50
#define MAX_WORD_LEN 50
#define MAX_PATH_LEN 2500



Similarity::Similarity(string dataset_file, string conf_file)
{

		ifstream fin(dataset_file.c_str());
		if(!fin)
		{
				cerr<<"Can not open "<<dataset_file<<"\n";
				exit(-1);
		}

		string str;
		while(getline(fin,str))
		{
				double quality;
				string id1, id2, s1,s2;
				vector <string> tokens;
				Tokenize_with_delimiter(str,&tokens,"\t");
				StringPair a;
				assert(tokens.size() == 5);
				if(tokens[0] == "0")
						quality = 0;
				else quality = 1;
				id1 = tokens[1];
				id2 = tokens[2];
				Lowercase_string(tokens[3]);
				Lowercase_string(tokens[4]);
				s1 = tokens[3];
				s2 = tokens[4];
				a.quality = quality;
				a.id1 = id1;
				a.id2 = id2;
				a.s1 = s1;
				a.s2 = s2;
				data.push_back(a);
		}

		fin.close();
		fin.open(conf_file.c_str());
		if(!fin)
		{
				cerr<<"Can not open "<<conf_file<<"\n";
				exit(-1);
		}
		fin>>metric;
		cout<<":"<<metric<<":is the metric \n\n";
		if(metric != "Jaccard" && metric != "Cosine" && metric != "PSpectrumKernel" && metric != "Random" && metric != "LengthWeightedKernel")
		{
				cerr<<"Not a supported similarity metric\n";
				cerr<<"Supported metrics\n1. Jaccard\n2. Cosine\n3. PSpectrumKernel\n";
				exit(-1);
		}
		if(metric == "PSpectrumKernel")
		{
				fin>>p;
		}
		else p = -1;
		if(metric != "Random")
		{
			fin>>threshold;
		}
		fin>>binary_scoring;
		cout<<"Done reading the data\n";
}




double Similarity::CosineSimilarity(char *st1, char *st2)
{
		
		double sim=0.0;
		char *tokenPtr;

		int i=0,j=0,found=0;

		int len1=0,len2=0;//lengths of st1 and st2

		int norm_len1=0, norm_len2=0;

		char words1[MAX_WORDS][MAX_WORD_LEN];
		char words2[MAX_WORDS][MAX_WORD_LEN];

		char s1[MAX_PATH_LEN];
		char s2[MAX_PATH_LEN];

		int freq1[MAX_WORDS];
		int freq2[MAX_WORDS];

		strcpy(s1,st1);
		strcpy(s2,st2);

		for (i=0;i<MAX_WORDS;i++)
				freq1[i]=0;

		for (i=0;i<MAX_WORDS;i++)
				freq2[i]=0;
		tokenPtr = strtok(s1, " ");

		if (tokenPtr!=NULL){
				strcpy(words1[len1],tokenPtr);
				freq1[len1]++;
				len1++;
		}

		tokenPtr = strtok(NULL," ");

		while (tokenPtr != NULL){
				for (i=0;i<len1;i++){
						if (strcmp(words1[i],tokenPtr) ==0){
								freq1[i]++;
								found=1;
								break;

						}

				}

				if (!found){

						strcpy(words1[len1],tokenPtr);
						freq1[len1]++;
						len1++;

				}

				tokenPtr = strtok(NULL," ");
				found=0;

		}


		tokenPtr = strtok(s2," ");


		if (tokenPtr!=NULL){
				strcpy(words2[len2],tokenPtr);
				freq2[len2]++;
				len2++;
		}

		tokenPtr = strtok(NULL," ");

		found = 0;

		while (tokenPtr != NULL){

				for (i=0;i<len2;i++){
						if (strcmp(words2[i],tokenPtr) ==0){
								freq2[i]++;
								found=1;
								break;

						}

				}

				if (!found){

						strcpy(words2[len2],tokenPtr);
						freq2[len2]++;
						len2++;
				}

				tokenPtr = strtok(NULL," ");
				found=0;

		}

		//calculating cosine similarity
		for (i=0;i<len1;i++){
				for (j=0;j<len2;j++){
						if (strcmp(words1[i],words2[j]) == 0)
								sim=sim + freq1[i]*freq2[j];
				}
		}
		for (i=0;i<len1;i++)
				norm_len1=norm_len1 + freq1[i]*freq1[i];

		for (i=0;i<len2;i++)
				norm_len2=norm_len2 + freq2[i]*freq2[i];

		sim = sim/sqrt(norm_len1*norm_len2);

		return sim;
}


void Similarity::CosineSimilarityEval()
{
		for(int i=0;i < (int)data.size();i++)
		{
				double score = CosineSimilarity((char *)(data[i].s1).c_str(),(char *)(data[i].s2).c_str());
				scores.push_back(score);

				//cout<<"1. "<<data[i].s1<<"\n2. "<<data[i].s2<<"\n"<<score<<"\n"<<data[i].quality<<"\n\n";

				if((i+1)%100 == 0)
						cout<<"computed similarity scores for "<<i+1<<" pairs\n";
		}


}




double Similarity::PSpectrumKernel(string s1, string s2)
{
		Real   k1=0.0, k2=0.0, k3=0.0, k4=0.0;
		Real   param = 0.0;

		int swf = 2;
		param = (double)p;

		s1 += SENTINEL;
		s2 += SENTINEL;

		StringKernel sk1(s1.size(), (SYMBOL*)s1.c_str(), swf, param);
		sk1.Set_Lvs();
		sk1.PrecomputeVal();

		StringKernel sk2(s2.size(), (SYMBOL*)s2.c_str(), swf, param);
		sk2.Set_Lvs();
		sk2.PrecomputeVal();

		//' kernel evaluations
		sk1.Compute_K((SYMBOL*)s1.c_str(), s1.size()-1, k1);  // ignore SENTINEL
		sk2.Compute_K((SYMBOL*)s2.c_str(), s2.size()-1, k2);  // ignore SENTINEL
		sk1.Compute_K((SYMBOL*)s2.c_str(), s2.size()-1, k3);  // ignore SENTINEL
		sk2.Compute_K((SYMBOL*)s1.c_str(), s1.size()-1, k4);  // ignore SENTINEL

		return k3/sqrt(k1*k2);

}


double Similarity::LengthWeightedKernel(string &s1, string &s2)
{
		Real   k1=0.0, k2=0.0, k3=0.0, k4=0.0;
		Real   param = 0.0;

		int swf = 1;
		param = (double)p;

		s1 += SENTINEL;
		s2 += SENTINEL;

		StringKernel sk1(s1.size(), (SYMBOL*)s1.c_str(), swf, param);
		sk1.Set_Lvs();
		sk1.PrecomputeVal();

		StringKernel sk2(s2.size(), (SYMBOL*)s2.c_str(), swf, param);
		sk2.Set_Lvs();
		sk2.PrecomputeVal();

		//' kernel evaluations
		sk1.Compute_K((SYMBOL*)s1.c_str(), s1.size()-1, k1);  // ignore SENTINEL
		sk2.Compute_K((SYMBOL*)s2.c_str(), s2.size()-1, k2);  // ignore SENTINEL
		sk1.Compute_K((SYMBOL*)s2.c_str(), s2.size()-1, k3);  // ignore SENTINEL
		sk2.Compute_K((SYMBOL*)s1.c_str(), s1.size()-1, k4);  // ignore SENTINEL

		return k3/sqrt(k1*k2);

}


void Similarity::PSpectrumKernelEval()
{
		for(int i=0;i<(int)data.size();i++)
		{
				double score = PSpectrumKernel(data[i].s1, data[i].s2);
				//cout<<"1. "<<data[i].s1<<"\n2. "<<data[i].s2<<"\n"<<score<<"\n"<<data[i].quality<<"\n";
				scores.push_back(score);
				if((i+1)%100 == 0)
						cout<<"computed similarity scores for "<<i+1<<" pairs\n";
		}
}


void Similarity::LengthWeightedKernelEval()
{
		for(int i=0;i<(int)data.size();i++)
		{
				double score = LengthWeightedKernel(data[i].s1, data[i].s2);
				scores.push_back(score);
				if((i+1)%100 == 0)
						cout<<"computed similarity scores for "<<i+1<<" pairs\n";
		}
}





double Similarity::JaccardSimilarity(string &s1, string &s2)
{
		vector <string> tokens1;
		vector <string> tokens2;
		Tokenize_with_delimiter(s1, &tokens1, " ?\t\".,;!\n");
		Tokenize_with_delimiter(s2, &tokens2, " ?\t\".,;!\n");
		int common_tokens = num_common_tokens(tokens1,tokens2);
		int total_distinct_tokens = tokens1.size() + tokens2.size() - common_tokens;
		double similarity = (double)common_tokens/total_distinct_tokens;
		return similarity;
}

void Similarity::JaccardSimilarityEval()
{	
		for(int i=0;i<(int)data.size();i++)
		{
				double score = JaccardSimilarity(data[i].s1, data[i].s2);	
				cout<<"1. "<<data[i].s1<<"\n2. "<<data[i].s2<<"\n"<<score<<"\n"<<data[i].quality<<"\n\n";
				scores.push_back(score);
				if((i+1)%100 == 0)
						cout<<"computed similarity scores for "<<i+1<<" pairs\n";

		}
}

void Similarity::RandomEval()
{
		srand((unsigned)time(0)); 
		for(int i=0;i< (int) data.size();i++)
		{
				int random_integer = rand()%100;
				if(	random_integer > 50)
				{
						scores.push_back(1);
				}
				else scores.push_back(0);
		}
}

double Similarity::Eval()
{
		if(metric == "Jaccard")
		{
				JaccardSimilarityEval();
		}
		else if (metric == "Cosine")
		{
				CosineSimilarityEval();
		}
		else if(metric == "PSpectrumKernel")
		{
				PSpectrumKernelEval();
		}
		else if(metric == "Random")
		{
				RandomEval();
		}

		else if(metric == "LengthWeightedKernel")
		{
				LengthWeightedKernelEval();
		}
		int matches = 0;
		if(scores.size() != data.size())
		{
				cerr<<" Could not compute similarity score for every pair\n";
				exit(-1);
		}
		if(binary_scoring == true)
		{
				for(int i=0;i < (int) scores.size();i++)
				{
						if(scores[i] <= threshold && data[i].quality == 0.0)
						{
								matches++;
						}
						if(scores[i] > threshold && data[i].quality == 1.0)
						{
								matches++;
						}
				}
				cout<<"Accuracy of "<<metric<<" is "<<(double)matches/(scores.size())<<"\n";
				return (double)matches/scores.size();
		}
		else
		{
				cerr<<"Binary scoring has only been implemented till now\n";
				return 0;
		}
}
