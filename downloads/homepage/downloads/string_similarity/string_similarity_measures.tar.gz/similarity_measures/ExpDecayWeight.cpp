#ifndef EXPDECAYWEIGHT_CPP
#define EXPDECAYWEIGHT_CPP

#include "ExpDecayWeight.h"
#include <cmath>
#include <cassert>


/**
 *  Exponential Decay weight function.
 *  W(y,t) := (lambda^{-gamma} - lambda^{-tau}) / (lambda - 1)
 *
 *  \param floor_len - (IN) Length of floor interval of matched substring.
 *                            (cf. gamma in VisSmo02).
 *  \param x_len     - (IN) Length of the matched substring.
 *                            (cf. tau in visSmo02).
 *  \param weight    - (OUT) The weight value.
 *
 */

ErrorCode
ExpDecayWeight::ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len,	Real &weight)

// ErrorCode
// ExpDecayWeight::ComputeWeight(const Real &floor_len, const Real &x_len,	Real &weight)
{
	//' Input validation
	assert(x_len >= floor_len);
	
	//' x_len == floor_len when the substring found ends on an interval.
	if(floor_len == x_len) {
		//' substring ended on an interval, so, get the val from val[]
		weight = 0.0;
	}
	else {
		//weight = (pow(-(floor_len-1), lambda) - pow(-x_len, lambda)) / (1-lambda);
    //weight = (pow(lambda,((Real)floor_len)) - pow(lambda, (Real)x_len+1)) / (1-lambda);
    //     double a=floor_len*-1.0;
    //     double b=x_len*-1.0;
    //     weight = (pow(lambda,a) - pow(lambda, b)) / (lambda-1);
    weight = (pow(lambda,-1.0*floor_len) - pow(lambda, -1.0*x_len)) / (lambda-1);
  }
  
//   std::cout << "floor_len : " << floor_len
//             << "   x_len : " << x_len
//             << "   pow1 : " << pow(lambda,-((Real)floor_len))
//             << "   pow2 : " << pow(lambda,-(Real)x_len)
//             << "   weight : " << weight << std::endl;

	return NOERROR;
}

#endif
