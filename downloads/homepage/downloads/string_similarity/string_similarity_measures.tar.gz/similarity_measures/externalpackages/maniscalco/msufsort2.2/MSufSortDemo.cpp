/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the MSufSort suffix sorting algorithm (Version 2.2).
 *
 * The Initial Developer of the Original Code is
 * Michael A. Maniscalco
 * Portions created by the Initial Developer are Copyright (C) 2006
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 *   Michael A. Maniscalco
 *
 * ***** END LICENSE BLOCK ***** */

#include <time.h>
#include <stdio.h>
//#include <conio.h>
#include <stdlib.h>
#include <string.h>

#include "MSufSort.h"
#include "BWT.h"




void LoadSourceFile(char * fileName, SYMBOL_TYPE * & data, int & length)
{
	// loads the source file into a buffer.
	data = 0;
	length = 0;

	FILE * fp = fopen(fileName, "rb");
	if (fp == 0)
		return;

	fseek(fp, 0, SEEK_END);
	length = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	if (length < 1)
		return;

	data = (SYMBOL_TYPE *)(new char[length]);

	fread(data, 1, length, fp);
	fclose(fp);
}





char * GetFileName(char * filename)
{
	int len = (int)strlen(filename);
	char * ret = filename + len;
	while ((ret > filename) && (ret[0] != '\\'))
		ret--;
	if (ret[0] == '\\')
		ret++;
	return ret;
}









bool IsBwtFile(char * fileName)
{
	// returns true if filename has .bwt extension.
	int n = (int)strlen(fileName);
	if (n < 4)
		return false;
	if (strncmp(&fileName[n - 4], ".bwt", 4) == 0)
		return true;
	return false;
}





void CreateBwtFileName(char * inputFileName, char * & bwtFileName)
{
	// create output bwt file name from original input file name.
	int inLen = (int)strlen(inputFileName);
	int n = inLen;
	while (--n > 0)
	{
		switch (inputFileName[n])
		{
			case '.':
			{
				bwtFileName = new char[n + 5];
				strncpy(bwtFileName, inputFileName, n + 1);
				bwtFileName[n + 1] = 'b';
				bwtFileName[n + 2] = 'w';
				bwtFileName[n + 3] = 't';
				bwtFileName[n + 4] = 0;
				return;
			}
	
			case '\\':
			case '/':
				break;
		}
	}

	bwtFileName = new char[inLen + 5];
	sprintf(bwtFileName, "%s.bwt", inputFileName);
}





int CreateOriginalFileName(char * bwtFileName, char * bwtFile, char * & outputFileName)
{
	// creates the original file name from which the bwt file came.
	// int inLen = (int)strlen(bwtFileName);
	int originalExtLen = 0;
	while (bwtFile[originalExtLen] != 0)
		originalExtLen++;

	outputFileName = new char[2048];
	int p = (int)(strlen(bwtFileName) - 4);
	strncpy(outputFileName, bwtFileName, p);
	strncpy(&outputFileName[p], bwtFile, originalExtLen);

	outputFileName[p + originalExtLen] = 0;

	return originalExtLen + 1;
}








void ForwardBWT(char * file)
{
	// test the MSufSort algorithm for use with the burrows wheeler transform
	SYMBOL_TYPE * sourceBuffer;
	int size;
	BWT bwt;

	printf("\n\nProcessing: %s\n", GetFileName(file));

	LoadSourceFile(file, sourceBuffer, size);

	if (sourceBuffer == 0)
	{
		printf("Invalid source or source of zero length\n");
		return;
	}
	#ifdef SORT_16_BIT_SYMBOLS
		if (size & 1)
		{
			printf("This demo is compiled with to sort 16 bit symbols.\n");
			printf("The input file is odd length and so, it is not 16 bit symbols.\n");
			delete [] sourceBuffer;
			return;
		}
	#endif

	// Call forward BWT
	unsigned int key = bwt.Forward((SYMBOL_TYPE *)sourceBuffer, size / sizeof(SYMBOL_TYPE));

	// save the BWT to file.
	char * outputFile;
	CreateBwtFileName(file, outputFile);
	FILE * outFP = fopen(outputFile, "wb");

	// output original file ext. (zero terminated)
	int p = (int)strlen(file);
	int n = ((int)strlen(outputFile) - 4);
	if ((p - n) > 0)
		fwrite(&file[n], 1, p - n, outFP);
	fputc(0, outFP);

	// output the key needed to reverse the BWT.
	fwrite((char *)&key, 1, 4, outFP);
	
	// output the BWT
	fwrite(sourceBuffer, 1, size, outFP);
	fclose(outFP);

	// clean up and done.
	delete [] outputFile;
	delete [] sourceBuffer;
}




void ReverseBWT(char * file)
{
	// undo the bwt file created with TestForwardBWT()
	SYMBOL_TYPE * sourceBuffer;
	int size;

	LoadSourceFile(file, sourceBuffer, size);
	if (sourceBuffer == 0)
	{
		printf("Invalid source or source of zero length\n");
		return;
	}

	BWT bwt;
	// create the output file name.
	char * outputFileName = 0;
	int keyOffset = CreateOriginalFileName(file, (char *)sourceBuffer, outputFileName);

	// get the reverse bwt 32 bit key.
	char * cPtr = (char *)sourceBuffer;
	int * key = (int *)&cPtr[keyOffset];

	printf("\n\nProcessing: %s\n", file);

	// Call reverse BWT
	size -= (keyOffset + 4);
	size /= sizeof(SYMBOL_TYPE);
	bwt.Reverse((SYMBOL_TYPE *)&cPtr[(keyOffset + 4)], size, *key);

	// write out reversed bwt.
	FILE * outFP = fopen(outputFileName, "wb");
	fwrite(&cPtr[(keyOffset + 4)], 1, size * sizeof(SYMBOL_TYPE), outFP);
	fclose(outFP);

	delete [] outputFileName;
	delete [] sourceBuffer;
}






int main(int argc, char * argv[])
{
	printf("MSufSort version 2.2\n");
	printf("November 3, 2005\n");
	printf("by M.A. Maniscalco\n");
	printf("web: http://www.michael-maniscalco.com\n");
	printf("email: michael@michael-maniscalco.com\n");
	#ifdef SORT_16_BIT_SYMBOLS
		printf("This build has the 16 bit symbol feature enabled.\n");
	#endif
	printf("------------------------------------------------------\n\n\n");

	for (int i = 1; i < argc; i++)
	{
		if (IsBwtFile(argv[i]))
			ReverseBWT(argv[i]);
		else
			ForwardBWT(argv[i]);
	}

	printf("All tasks completed.\n");
	//getch();
	system("pause");
}

