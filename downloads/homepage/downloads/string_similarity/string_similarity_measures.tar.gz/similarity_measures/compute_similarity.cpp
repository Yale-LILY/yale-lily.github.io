#include <cstdlib>
#include <iomanip>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>

#include "strutils.h"
#include "Similarity.h"

#define threshold 0.4

using namespace std;


bool sort_func(pair <int, double> a, pair<int, double> b)
{
		return a.second > b.second;
}
int minimum(int a,int b,int c)
/*Gets the minimum of three values*/
{
  int min=a;
  if(b<min)
    min=b;
  if(c<min)
    min=c;
  return min;
}
int levenshtein_distance(string &s,string &t)
/*Compute levenshtein distance between s and t*/
{
  //Step 1
  int k,i,j,n,m,cost,*d,distance;
  n=s.length(); 
  m=t.length();
  if(n!=0&&m!=0)
  {
    d=(int *)malloc((sizeof(int))*(m+1)*(n+1));
    m++;
    n++;
    //Step 2	
    for(k=0;k<n;k++)
	d[k]=k;
    for(k=0;k<m;k++)
      d[k*n]=k;
    //Step 3 and 4	
    for(i=1;i<n;i++)
      for(j=1;j<m;j++)
	{
        //Step 5
        if(s[i-1]==t[j-1])
          cost=0;
        else
          cost=1;
        //Step 6			 
        d[j*n+i]=minimum(d[(j-1)*n+i]+1,d[j*n+i-1]+1,d[(j-1)*n+i-1]+cost);
      }
    distance=d[n*m-1];
    free(d);
    return distance;
  }
  else 
    return -1; //a negative return value means that one or both strings are empty.
}

void compute_similarity(vector <pair<string, string> > &authors1, vector <pair<string, string> > &authors2)
{
	for(int i=0;i<authors1.size();i++)
	{ 
		clock_t start, finish;
		double time;
		start = clock();

		int best_match = -1;
		double max_sim = -1;
		vector <pair<int,double> > top_matches;
		for(int j=0;j<authors2.size();j++)
		{
			Similarity s;

			double sim1 = s.JaccardSimilarity(authors1[i].second,authors2[j].second);
			if(sim1 < 0.45) continue;
			//cout<<"similarity between\n"<<authors1[i].second<<"\n"<<authors2[j].second<<"\n"<<sim1<<"\n";
			//double sim2 = s.PSpectrumKernel(authors1[i].second, authors2[j].second);
			//cout<<sim2<<"\n";

			if(sim1 >= threshold && sim1 > max_sim)
			{
				max_sim = sim1;
				best_match = j;
				//cout<<"inserting "<<authors2[j].second<<" with similarity of "<<sim2<<"\n";
				top_matches.push_back(make_pair(j, sim1));
				sort(top_matches.begin(), top_matches.end(), sort_func);
				int max_size = top_matches.size() > 3 ? 3 : top_matches.size();
				top_matches.resize(max_size);
			}
		}
		if(max_sim >= threshold)
		{
			cout<<authors1[i].second<<"\n\n";
			for(int i=0;i<top_matches.size();i++)
			{
				cout<<i+1<<":\t"<<authors2[top_matches[i].first].first<<" "<<authors2[top_matches[i].first].second<<"\n";
			}
			cout<<"\n\n";
		}
		finish = clock();
		time = double(finish - start) / CLOCKS_PER_SEC;
		//cout << "\ttime for 1 author " << time <<"\n";
	}
}

void read_input(string input_file, vector <pair<string, string> > &authors)
{
	ifstream fin(input_file.c_str());
	string str;
	while(getline(fin,str))
	{
		vector <string> tokens;
		Tokenize_with_delimiter(str, &tokens, "\t");

		authors.push_back(make_pair(tokens[0],tokens[1]));
	}
}


int main(int argc, char *argv[])
{
	string input_file1(argv[1]);
	string input_file2(argv[2]);

	vector <pair<string,string> > authors1;
	vector <pair<string,string> > authors2;

	read_input(input_file1, authors1);
	read_input(input_file2, authors2);

	compute_similarity(authors1, authors2);
	return 0;
}

