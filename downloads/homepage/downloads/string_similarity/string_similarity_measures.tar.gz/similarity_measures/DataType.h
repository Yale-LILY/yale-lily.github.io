#ifndef DATATYPE_H
#define DATATYPE_H

#define UInt32  unsigned int
#define UInt64  unsigned long long
#define Byte1   unsigned char
#define Byte2   unsigned short
#define Real    double
#define SENTINEL '\n'

#ifndef UNICODE
#  define SYMBOL  Byte1
#else
#  define SYMBOL  Byte2
#endif

#endif
