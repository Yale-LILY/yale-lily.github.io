#ifndef CONSTANTWEIGHT_H
#define CONSTANTWEIGHT_H

#include "DataType.h"
#include "ErrorCode.h"
#include "I_WeightFactory.h"
#include <iostream>


//' Constant weight class
class ConstantWeight : public I_WeightFactory
{
 public:
  
	/// Constructor
	ConstantWeight(){}
  
	/// Destructor
	virtual ~ConstantWeight(){}

	/// Compute weight
	ErrorCode ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len, Real &weight);
};
#endif
