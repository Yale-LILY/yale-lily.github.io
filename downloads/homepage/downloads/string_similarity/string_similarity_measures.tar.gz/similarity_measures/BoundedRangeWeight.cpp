#ifndef BOUNDEDRANGEWEIGHT_CPP
#define BOUNDEDRANGEWEIGHT_CPP

#include "BoundedRangeWeight.h"
#include <cassert>


#define MIN(x,y) (((x) < (y)) ? (x) : (y))
#define MAX(x,y) (((x) > (y)) ? (x) : (y))


/** Bounded Range weight function.
 *  W(y,t) := max(0,min(tau,n)-gamma)
 *
 *  \param floor_len The length of floor interval of matched substring. (cf. gamma in VisSmo02).
 *  \param x_len The length of the matched substring. (cf. tau in visSmo02).
 *  \param weight The weight value.
 *
 */
ErrorCode
BoundedRangeWeight::ComputeWeight(const UInt32 &floor_len, const UInt32 &x_len,	Real &weight)
{
	//' Input validation
	assert(x_len >= floor_len);
		
	//' x_len == floor_len when the substring found ends on an interval.

	Real tau = (Real)x_len;
	Real gamma = (Real)floor_len;

	weight = MAX(0,MIN(tau,n)-gamma);
  
//   std::cout << "floor_len:"<<floor_len 
//             << "  x_len:"<<x_len
//             << "  weight:"<<weight << std::endl;

	return NOERROR;
}

#endif
