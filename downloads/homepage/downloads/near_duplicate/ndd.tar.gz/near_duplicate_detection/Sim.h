#ifndef SIMILARITY
#define SIMILARITY

#include <boost/numeric/ublas/triangular.hpp>       // more space, but faster
#include <boost/numeric/ublas/matrix.hpp>           // more space, but faster
//#include <boost/numeric/ublas/matrix_sparse.hpp>  // less space, but slower

#include <boost/numeric/ublas/io.hpp>


using namespace boost::numeric::ublas;



typedef triangular_matrix<float, upper> Similarity; //  the similarity matrix
//typedef matrix<float> Similarity; //  the similarity matrix
//typedef mapped_matrix<float> Similarity; //  the similarity matrix



#endif
