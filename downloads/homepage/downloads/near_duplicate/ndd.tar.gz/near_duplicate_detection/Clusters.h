#ifndef CLUSTER
#define CLUSTER
#include <algorithm>
#include <boost/tokenizer.hpp>
#include "conf.h"
#include "DocumentSpace.h"
#include <map>
#include <set>
#include <vector>
 
typedef std::set<unsigned int> cluster;
typedef std::vector<cluster> Clusters;


/*
 *  compare clusters by size
 */


struct compareSizeClusters{

  bool operator() (const cluster& cl1, const cluster& cl2){

    return cl1.size() > cl2.size();
  }
  
};

#endif
