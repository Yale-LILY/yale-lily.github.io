#ifndef DOCUMENT_SPACE
#define DOCUMENT_SPACE
#include <vector>
#include <string>


class DocumentSpace{
  
 public:
  

  // a docid type
  typedef unsigned long long docID;  // the document id type
  
  // a document is a string
  typedef std::string Document;

  // the document space
  typedef std::vector<std::pair<Document, std::string> > DS;  

  /* 
   * Read a documentd into the DocumentSpace
   *
   * \param meta index for document filenames
   *
   */
  docID loadDocuments(const char *);

  /* 
   * Read a document into the DocumentSpace
   *
   * \param the document filename
   *
   */
  void loadDocument(const char *);


  void dumpDocument(docID) const;
  std::string getDocument(docID);

  /*
   * dump all documents
   *
   */
  void dumpDocuments() const;
  
  /*
   * iterators
   */
  typedef DS::const_iterator const_iterator;
  inline const_iterator begin() const { return ds_.begin();};
  inline const_iterator end() const { return ds_.end();};
  inline const docID size() const {return ds_.size();}


 private:
  DS ds_;  // each document is a string
};


#endif
