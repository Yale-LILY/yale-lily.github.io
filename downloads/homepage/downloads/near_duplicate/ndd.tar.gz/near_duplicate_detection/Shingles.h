#ifndef SHINGLES
#define SHINGLES
#include "DocumentSpace.h"
#include "Sim.h"


class Shingles{

 public:

  typedef unsigned short size_signatures;
  typedef std::pair<uint32_t, DocumentSpace::docID> sign_doc;
  typedef std::vector<sign_doc> SignDocVect;

  //
  // The constructur, initialize prime_, and  A_, B_, MIN_ vectors
  //
  //

  Shingles(unsigned short numberSignatures, 
	   DocumentSpace::docID currentNumDocs): 
    numberSignatures_(numberSignatures){

    //2^31 - 1 is prime
    prime_ =  static_cast<uint32_t>(pow(2,31)-1);
    srand(time(NULL));

    for (unsigned int i = 0; i < numberSignatures; i++){

      A_.push_back( rand() % prime_ + 1);
      B_.push_back( rand() % prime_ + 1);
      MIN_.push_back(prime_ + 1);
    }    
    
    // allocate the space for the comparison of shingles
    signDoc_.reserve(numberSignatures * currentNumDocs);
  };

/*
 * process all documents
 *
 * \param the DocumentSpace
 * \param the size of the single
 * \param the maxWordsInADocumentFromBeginning
 *
 */
  void computeShingles(const DocumentSpace &,
		       const unsigned short,
		       const unsigned int);

  /*
   * dump similarity
   *
   */

  /* used on a sorted vector <signature, docID>
   *
   * param the similarity matrix
   *
   */
  
  void computeSimilarity(Similarity *);

  
 private:
  size_signatures numberSignatures_;
  
  uint32_t prime_;

  std::vector<uint32_t> A_;  // A_, as in a X + b mod prime_
  std::vector<uint32_t> B_;  // B_, as in a X + b mod prime_
  std::vector<uint32_t> MIN_;// current MIN_HASH

  SignDocVect signDoc_;      // contains the pairs <signature, docID>
 
  // used for comparing signDoc_
 
  struct compareSignDoc{

    bool operator()(const sign_doc& rpStart, const sign_doc& rpEnd){

      if (rpStart.first == rpEnd.first)         // in case of tie on shingle
	return rpStart.second < rpEnd.second; // order by docID
      else        
	return rpStart.first < rpEnd.first;
    }
  };

};

#endif
