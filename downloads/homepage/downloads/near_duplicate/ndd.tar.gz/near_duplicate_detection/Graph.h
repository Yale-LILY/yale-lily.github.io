#ifndef GRAPH
#define GRAPH
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/connected_components.hpp>

using namespace boost;

class Graph{

 public:
  typedef adjacency_list<vecS, vecS, undirectedS> graph;
  typedef unsigned int node;

  /*
   * add a new edge
   *
   * \param node21
   * \param node2
   */

  void inline add(node n1, node n2) 
    { add_edge(n1, n2, G_); }
  

  /*
   * compute connected components
   *
   * \param components, a vector containing the components
   *
   */

  unsigned int connectedComponents(std::vector<node> * components) const{

    return connected_components(G_, &((*components)[0]));
  }

  unsigned int inline numVertices() const { return num_vertices(G_); }


 private:
  graph G_;
};
#endif
