
// the maximum number of words considered in a document
//
#define SHG_MAX_WORDS_CONSIDERED_IN_DOCUMENT 500

// the tokenizer separators
//
#define SHG_WORDS_SEPARATORS " -;.|:,/\n'\"-"

#define THRESHOLD 0.75


// the single size
//
#define SHINGLE_SIZE 3
