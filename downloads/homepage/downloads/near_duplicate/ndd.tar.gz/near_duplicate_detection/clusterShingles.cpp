#include <iostream>
#include <fstream>
#include <boost/program_options.hpp>

#include "DocumentSpace.h"
#include "Shingles.h"
#include "Sim.h"
#include "Graph.h"
#include "Clusters.h"
#include <algorithm>
#include <ctime>                           // for timing

#define threshold 0.1

using namespace boost;

namespace po = boost::program_options;

int main(int argc, char *argv[]){

	// PROGRAM OPTIONS

	float sim_th = 0.75;
	unsigned int shingle_size = 3;
	unsigned int num_hashes = 100; 
	unsigned int maxWordsInADocumentFromBeginning = 500;
	unsigned int minClusterSize = 4;
	bool dump_sim = false;
	std::string meta_file;

	boost::program_options::options_description desc("Allowed options");
	desc.add_options()
		("help", "produce help message")
		("similarity_th", po::value<float>(), "the similarity_threshold")
		("shingle_size", po::value<int>(), "the shingle size")
		("number_hashes", po::value<int>(), "the number of hash functions used")
		("maxWordsInADocumentFromBeginning", po::value<int>(), "maxWordsInADocumentFromBeginning")
		("minClusterSize", po::value<int>(), "minClusterSize")
		("dump_sim", "dump the similarity")
		("meta_file", po::value<std::string>(), "the meta file containing the files to cluster");
	;
	po::variables_map vm;
	po::store(po::parse_command_line(argc, argv, desc), vm);
	po::notify(vm);  

	if (vm.count("help")){
		std::cout << desc << std::endl;
		return 1;
	}

	if (vm.count("similarity_th"))  
		sim_th=vm["similarity_th"].as<float>(); 
	std::cout << "Setting similarity threshold to " << sim_th << std::endl;

	if (vm.count("shingle_size")) 
		shingle_size=vm["shingle_size"].as<int>(); 
	std::cout << "Setting shingle_size to " << shingle_size << std::endl;

	if (vm.count("number_hashes")) 
		num_hashes=vm["number_hashes"].as<int>(); 
	std::cout << "Setting number_hashes to " << num_hashes << std::endl;

	if (vm.count("maxWordsInADocumentFromBeginning")) 
		maxWordsInADocumentFromBeginning
			=vm["maxWordsInADocumentFromBeginning"].as<int>(); 
	std::cout << "Setting maxWordsInADocumentFromBeginning to " 
		<< maxWordsInADocumentFromBeginning << std::endl;

	if (vm.count("minClusterSize")) 
		minClusterSize=vm["minClusterSize"].as<int>(); 
	std::cout << "minClusterSize to " << minClusterSize << std::endl;

	if (vm.count("dump_sim")) 
		dump_sim = true;

	if (vm.count("meta_file"))
		meta_file = vm["meta_file"].as<std::string>();
	else 
		meta_file = std::string("./data/meta.index"); 
	std::cout << "Loading from meta file " << meta_file << std::endl;

	//  
	// start the program
	//

	//
	// create and load the document space
	//
	DocumentSpace ds;
	DocumentSpace::docID numberDocuments = 
		ds.loadDocuments(meta_file.c_str());
	std::cout << "read " << numberDocuments << " documents " << std::endl;
	//  ds.dumpDocuments();


	//
	// shingle documents
	//
	Shingles sh(num_hashes, numberDocuments);

	//
	// Get the similarity
	//
	//  Similarity sim(numberDocuments,
	//		 numberDocuments,
	//		 (numberDocuments * numberDocuments / 2) + 1);
	Similarity sim(numberDocuments+1,
			numberDocuments+1);
	for (unsigned i = 0; i<sim.size1(); i++)
		for (unsigned j = i+1; j<sim.size2(); j++)
			sim(i, j) = 0.0;


	//
	// compute shingles and similarity
	//

	sh.computeShingles(ds, shingle_size, maxWordsInADocumentFromBeginning);
	sh.computeSimilarity(&sim);

	// create a graph with all the nodes above a sim threshold

	clock_t start, finish;
	double time;
	start = clock();

	Graph G;

	for (unsigned i = 0; i<sim.size1(); i++){
		for (unsigned j = i+1; j<sim.size2(); j++){

			if (sim(i,j) > sim_th){
				G.add(i, j);

				if (dump_sim)
					std::cout << "* sim[" << i << "," << j<< "]=" 
						<< sim(i,j)<< std::endl;
			}
		}
	}
	finish = clock();
	time = double(finish - start) / CLOCKS_PER_SEC;
	std::cout << "\ttime for building graph " << time << std::endl;
	start = clock();

	//
	// compute Graph's connected components
	//

	std::vector<Graph::node> * components = 
		new std::vector<Graph::node>(G.numVertices());

	unsigned int numClusters = 
		G.connectedComponents(components);

	std::cout << "There are " << numClusters << " components " << std::endl;

	finish = clock();
	time = double(finish - start) / CLOCKS_PER_SEC;
	std::cout << "\ttime for connected components " << time << std::endl;
	start = clock();

	// 
	// allocate a numClusters clusters
	Clusters cls(numClusters);

	// 
	// Insert in clusters
	//
	for (std::vector<Graph::node>::size_type i = 0; i!= components->size(); ++i){

		cls[(*components)[i]].insert(i);

		//std::cout << "Document " << i << " is in cluster " 
		//	      << (*components)[i] << std::endl;
	}

	//
	// sort clusters by size
	//

	sort(cls.begin(), cls.end(), compareSizeClusters());


	unsigned int i = 0;
	int num_clusters = 0;

	Clusters::const_iterator it_end = cls.end();
	for (Clusters::const_iterator it = cls.begin();
			it != it_end; ++it, ++i) {
		if (it->size() > minClusterSize){

			num_clusters++;
		}
		std::cout << "Cluster [" << i << "] size=" << it->size() << std::endl;

		cluster::const_iterator it_c_end = it->end();
		for (cluster::const_iterator it_c = it->begin();
				it_c != it_c_end;
				++it_c){

			std::cout << "DocID[" << *it_c << "] " ;

			ds.dumpDocument(*it_c);
		}

		std::cout << std::endl;


	}
	finish = clock();
	time = double(finish - start) / CLOCKS_PER_SEC;
	std::cout << "\tTotal time for clustering" << time << std::endl;
	start = clock();

}

