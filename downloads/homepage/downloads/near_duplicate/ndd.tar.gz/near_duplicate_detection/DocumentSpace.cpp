#include "DocumentSpace.h"


#include <iostream>
#include <fstream>


//Load a sequence of tweets from the metafile, each tweet is in its own line.
DocumentSpace::docID DocumentSpace::loadDocuments(const char * metafile){

	std::ifstream infile;
	std::string line;

	docID currentDoc = 0;

	infile.open(metafile, std::ios_base::in);
	// open the file

	if (!infile) {
		std::cerr << "Cannot open file " << metafile << std::endl;
		return 0;
	};

	while(infile){
		getline(infile, line);
		if (!infile.eof()){
			loadDocument((const char *)line.c_str());
			//    std::cout << "Loaded file " << std::string(filename) << std::endl;
			currentDoc++;
		}
	}

	infile.close();
	return currentDoc-1;
};

//Loads a single document
void DocumentSpace::loadDocument(const char * filename){
	std::string id;
	std::string doc;
	std::string fname(filename);
	int ind = fname.find_first_of("\t");
	id = fname.substr(0,ind);
	doc = fname.substr(ind+1,fname.length()-ind-1);

	ds_.push_back(make_pair(doc, std::string(id)));
};

// dump a single document
void DocumentSpace::dumpDocument(docID di) const{
	std::cout <<ds_[di].first << std::endl;
}

std::string DocumentSpace::getDocument(docID di) {
	return ds_[di].first;
}

// dump all the documents
void DocumentSpace::dumpDocuments() const{

	DS::const_iterator end = ds_.end();

	docID di = 0;
	for (DS::const_iterator it = ds_.begin();
			it != end;
			it ++){

		std::cout << "docId:" << ++di << it->first  <<"\n";
	}
}

