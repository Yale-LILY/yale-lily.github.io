#include "Shingles.h"
#include "conf.h"

#include <iostream>

#include <ctime>                           // for timing
#include <cmath>                           // for pow

#include <boost/tokenizer.hpp>             // for tokenizing a document
#include <boost/functional/hash.hpp>       // for hashing a word

//
// compute shingles
//

void Shingles::computeShingles(const DocumentSpace & ds,
			       const unsigned short shingleSize,
			       const unsigned int maxWordsInADocumentFromBeginning){

  clock_t start, finish;
  double time;

  start = clock();

  // create the hasher
  boost::hash<std::string> string_hash;

  // tokenize the document
  boost::char_separator<char> sep(SHG_WORDS_SEPARATORS);
  typedef boost::tokenizer<boost::char_separator<char> >  tokenizer;

  // vector containing #shingleSize tokenized words 
  typedef std::vector<std::size_t> vShingles;
  
  // a single shingleID
  std::size_t shingleID;

  // a single shingleHASH
  uint32_t shingleHash;
  
  //  
  // for each document
  //
  DocumentSpace::const_iterator it_end=ds.end();
  DocumentSpace::docID di = 0;
  for(DocumentSpace::const_iterator it=ds.begin(); it != it_end; 
      ++it, ++di){
    
    //std::cout << "\n\nDocument:" << di << std::endl;

    vShingles vHashedWords(shingleSize);

    // tokenize
    tokenizer tokens(it->first, sep);  

    // for each token
    unsigned int i=0;
    tokenizer::const_iterator tok_iter_end = tokens.end();
    for (tokenizer::const_iterator tok_iter = tokens.begin();
	 (tok_iter != tok_iter_end) &&
	   (i < maxWordsInADocumentFromBeginning); 
	 tok_iter++, i++){
      
      vHashedWords[ i % shingleSize ] = string_hash(*tok_iter);

      // map each token to an id
      //std::cout << "\n<" << *tok_iter << ", wID=" << 
      //string_hash(*tok_iter) << '>';
      
      if (i+1 >= shingleSize){  // skip to next if not yet a shingle-word
       
	// compute the shingle ID as sum of shingleSize words
	shingleID = 0;
	vShingles::const_iterator vs_it_end = vHashedWords.end();
	for(vShingles::const_iterator vs_it = vHashedWords.begin();
	    vs_it != vs_it_end;
	    vs_it++){
	  
	  //  std::cout << " | " << *vs_it;
	  shingleID = (shingleID + *vs_it);
	}   // each shingle
	
	//std::cout << " -> " << shingleID;

	// given a shingleID
	//   compute each hash function
	for (size_signatures j = 0; j < numberSignatures_; j++){
	  
	  // 32 + 32 bit = 64 mod prime_ -> 32 bit 
	  shingleHash = (((unsigned long long) A_[j] * 
			  (unsigned long long) shingleID)  + B_[j]) % prime_;
	  //std::cout << " shingleHash=" << shingleHash;
	
	  // take min_hash
	  if (shingleHash < MIN_[j]){
	    MIN_[j] = shingleHash;
	    //	    std::cout << "\n\tMIN SHINGLE[" <<j<< "]= " << shingleHash;
	  }
	} // each signature
      } // if is a valid shingle-word

    } // each word token
    
    // save the singles for di in a vector
    for (size_signatures j = 0; j < numberSignatures_; j++){

      //      std::cout << "\n\t["<<di
      //      << "] MIN SHINGLE[" <<j<< "]= " << MIN_[j];
      signDoc_.push_back(std::make_pair(MIN_[j], di));      
    }
    
    // REINIZIALIZE MIN
    for (unsigned int i = 0; i < numberSignatures_; i++)
      MIN_[i] = prime_;
    
  } // each document

  finish = clock();
  time = double(finish - start) / CLOCKS_PER_SEC;
  std::cout << "\ttime for shinglings documents " << time << std::endl;
  start = clock();
  
  // sort the vector
  sort(signDoc_.begin(), signDoc_.end(), compareSignDoc());
  
  finish = clock();
  time = double(finish - start) / CLOCKS_PER_SEC;
  std::cout << "\ttime for sorting <shingles, documents> pairs " 
	    << time << std::endl;
  
  //unsigned int i=0;
  //for(SignDocVect::const_iterator it = signDoc_.begin();
  //    it != signDoc_.end();
  //   ++it, ++i){
  //
  //  std::cout << "[" << i << "] signature " << 
  //    it->first << " " << it->second << "\n";
  //}
}

//
// compute similarity on a sorted vector <signature, docID>
//
void Shingles::computeSimilarity(Similarity * similarity){

  clock_t start, finish;
  double time;

  start = clock();
  

  // take a sorted vector <signature, docID>
  SignDocVect::const_iterator it_end = signDoc_.end();
  for (SignDocVect::const_iterator it = signDoc_.begin();
       it != it_end; ++it){

    // take next one (has the same signature)?
    SignDocVect::const_iterator it1 = it;
    ++it1;
    for (; (it->first == it1->first) && (it1 != it_end); ++it1){

      //      std::cout << "documents [" << it->second << "," << it1->second 
      //		<< "] have the same signature " << it->first << std::endl;

      // THIS was too EXPENSIVE FIXME with a sparse matrix
      //  Adopted a full matrix o(n^2) space but faster

      (*similarity)(it->second, it1->second) += 1.0;

      //std::cout << "\tcurrent similarity " << (*similarity)(it->second, it1->second) << std::endl;
    }

    it = it1-1;
  } 
  
  // now the matrix hold the similarity


  // we can safely remove the <signature, document> memory and free memory
  signDoc_.clear();

  // scale to the number of signatures
  (*similarity) /= numberSignatures_;

  finish = clock();
  time = double(finish - start) / CLOCKS_PER_SEC;
  std::cout << "\ttime for computing similarity " << time << std::endl;
  start = clock();
}


